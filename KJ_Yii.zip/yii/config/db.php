<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=Ksyju',
    'username' => 'root',
    'password' => 'ksyju25',
    'charset' => 'utf8',
];
