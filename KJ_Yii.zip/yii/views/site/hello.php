<h1>Welcome to the DoingITeasy Channel</h1>
<?= $name; ?>